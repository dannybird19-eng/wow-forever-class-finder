# WoW Forever Class Finder (Version 2)

A standalone, mobile-friendly class finder for WoW Forever. This version has 15 questions and does not ask a final “what class suits you?” question; the recommendation is calculated from the accumulated answers.

## Publish with GitHub Pages
1. Open your repository on GitHub.
2. Upload `index.html` to the repository root (replace the old file if prompted).
3. Commit the change.
4. Go to **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**, branch `main`, folder `/(root)`, then save.
6. Give Pages a few minutes to publish or update the site.

The file is standalone; it does not require a build step or external libraries.
