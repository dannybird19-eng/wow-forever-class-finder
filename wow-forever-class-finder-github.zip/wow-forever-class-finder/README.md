# WoW Forever Class Finder

A standalone, mobile-friendly class preference quiz for the nine WoW Classic-style classes.

## Publish with GitHub Pages (free HTTPS)

1. Sign in to https://github.com/ and create a new **public** repository, e.g. `wow-forever-class-finder`.
2. Upload `index.html` from this folder (and this README if you like) to the repository root. You can use **Add file → Upload files**.
3. Open the repository's **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Set branch to **main**, folder to **/(root)**, then click **Save**.
6. Wait a minute or two. The Pages section will show your public HTTPS URL, typically:
   `https://YOUR-USERNAME.github.io/wow-forever-class-finder/`

If the URL doesn't appear immediately, refresh the Pages settings after the deployment completes.

## Customize

Edit `index.html` to change the questions, styling, scoring, or descriptions. The quiz runs entirely in the browser and does not collect or send answers to a server.

Fan-made project; not affiliated with Blizzard Entertainment or WoW Forever.
